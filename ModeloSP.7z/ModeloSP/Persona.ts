namespace Persona{
    export class persona{
        nombre:string;
        apellido:string;
        edad:number;

        constructor(nombre:string,apellido:string,edad:number){
            if(nombre != undefined){
                this.nombre = nombre;
            }

            if(apellido != undefined){
                this.apellido = apellido;
            }

            if(edad != undefined){
                this.edad = edad;
            }
        }

        personaToJson():string{
            return JSON.stringify(this);
        }
    }
}