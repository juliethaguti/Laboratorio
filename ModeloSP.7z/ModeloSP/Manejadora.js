//npm install -g tsc
//tsc ./*.ts -w
var Persona;
(function (Persona) {
    $(document).ready(function () {
        $('#btnAgregar').click(manejadora.agregarEmpleado);
        $('#Mostrar').click(manejadora.mostrarEmpleados);
    });
    var manejadora = /** @class */ (function () {
        function manejadora() {
        }
        manejadora.agregarEmpleado = function () {
            var nombre = String($('#Nombre').val());
            var apellido = String($('#Apellido').val());
            var edad = Number($('#Edad').val());
            var horario = String($('#Horario').val());
            var legajo = Number($('#Legajo').val());
            var objeto = new Persona.empleado(nombre, apellido, edad, horario, legajo);
            manejadora.empleados = JSON.parse(localStorage.getItem('listaEmpleados'));
            manejadora.empleados.push(objeto);
            var lista = JSON.stringify(manejadora.empleados);
            localStorage.setItem('listaEmpleados', lista);
            //manejadora.limpiarFormulario();
            manejadora.mostrarEmpleados();
        };
        manejadora.limpiarFormulario = function () {
            $('#Nombre').val('');
            $('#Apellido').val('');
            $('#Legajo').val('');
            $('#Edad').val('');
        };
        manejadora.mostrarEmpleados = function () {
            manejadora.empleados = JSON.parse(localStorage.getItem('listaEmpleados'));
            var tabla = "";
            $("#cuerpoTabla").html(tabla);
            manejadora.empleados.map(function (empleado) {
                tabla = "<tr><td>";
                tabla += empleado.nombre;
                tabla += "</td><td>";
                tabla += empleado.apellido;
                tabla += "</td><td>";
                tabla += empleado.edad;
                tabla += "</td><td>";
                tabla += empleado.horario;
                tabla += "</td><td><a onclick='Persona.manejadora.eliminar(";
                tabla += empleado.legajo;
                tabla += ")'><span class='fa fa-trash-o'></span></a><a onclick='Persona.manejadora.modificar(";
                tabla += empleado.legajo;
                tabla += ")'><span class='fa fa-pencil-square-o'></span></a></td></tr>";
                $('#cuerpoTabla').append(tabla);
            });
        };
        manejadora.modificar = function (i) {
            manejadora.empleados = JSON.parse(localStorage.getItem('listaEmpleados'));
            $('#btnAgregar').html('Modificar');
            var nombre = String($('#Nombre').val());
            var apellido = String($('#Apellido').val());
            var edad = Number($('#Edad').val());
            var horario = String($('#Horario').val());
            var legajo = Number($('#Legajo').val());
            var objeto = new Persona.empleado(nombre, apellido, edad, horario, legajo);
            var index;
            for (var j = 0; j < manejadora.empleados.length; j++) {
                if (i == manejadora.empleados[j].legajo) {
                    index = j;
                }
            }
            console.log(index);
            $('#btnAgregar').click(function () {
                manejadora.empleados.splice(index, 1, objeto);
                localStorage.setItem('listaEmpleados', JSON.stringify(manejadora.empleados));
            });
        };
        manejadora.eliminar = function (i) {
            manejadora.empleados = JSON.parse(localStorage.getItem('listaEmpleados'));
            for (var j = 0; j < manejadora.empleados.length; j++) {
                if (i == manejadora.empleados[j].legajo) {
                    manejadora.empleados.splice(j, 1);
                    localStorage.setItem('listaEmpleados', JSON.stringify(manejadora.empleados));
                }
            }
            manejadora.mostrarEmpleados();
        };
        manejadora.prototype.filtrarPorHorario = function () { };
        manejadora.prototype.promedioEdadPorHorario = function () { };
        manejadora.empleados = new Array();
        return manejadora;
    }());
    Persona.manejadora = manejadora;
})(Persona || (Persona = {}));
