//npm install -g tsc
//tsc ./*.ts -w
namespace Persona{
    
    
    $(document).ready(function(){
        $('#btnAgregar').click(manejadora.agregarEmpleado);
        $('#Mostrar').click(manejadora.mostrarEmpleados);
    });
    export class manejadora{

        static empleados:Array<Persona.empleado> = new Array<Persona.empleado>();

        public static agregarEmpleado():void{
            let nombre:string = String($('#Nombre').val());  
            let apellido:string = String($('#Apellido').val());
            let edad:number = Number($('#Edad').val());
            let horario:string = String($('#Horario').val());
            let legajo:number = Number($('#Legajo').val());
            let objeto:Persona.empleado = new empleado(nombre, apellido, edad, horario,legajo);
            manejadora.empleados = JSON.parse(localStorage.getItem('listaEmpleados'));
            manejadora.empleados.push(objeto);
            
            let lista = JSON.stringify(manejadora.empleados);
            localStorage.setItem('listaEmpleados',lista);

            //manejadora.limpiarFormulario();
            manejadora.mostrarEmpleados();
        }

        static limpiarFormulario():void{
            $('#Nombre').val('');
            $('#Apellido').val('');
            $('#Legajo').val('');
            $('#Edad').val('');
            
        }
        static mostrarEmpleados():void{
            manejadora.empleados = JSON.parse(localStorage.getItem('listaEmpleados'));
            let tabla = "";
            $("#cuerpoTabla").html(tabla);

            manejadora.empleados.map(function(empleado){

                tabla = "<tr><td>";
                tabla += empleado.nombre;
                tabla += "</td><td>";
                tabla += empleado.apellido;
                tabla += "</td><td>";
                tabla += empleado.edad;
                tabla += "</td><td>";
                tabla += empleado.horario;
                tabla += "</td><td><a onclick='Persona.manejadora.eliminar(";
                tabla += empleado.legajo;
                tabla += ")'><span class='fa fa-trash-o'></span></a><a onclick='Persona.manejadora.modificar(";
                tabla += empleado.legajo;
                tabla +=")'><span class='fa fa-pencil-square-o'></span></a></td></tr>";
                $('#cuerpoTabla').append(tabla);
        });

    }

        static modificar(i:number):void{
            manejadora.empleados = JSON.parse(localStorage.getItem('listaEmpleados'));
            $('#btnAgregar').html('Modificar');
            let nombre:string = String($('#Nombre').val());  
            let apellido:string = String($('#Apellido').val());
            let edad:number = Number($('#Edad').val());
            let horario:string = String($('#Horario').val());
            let legajo:number = Number($('#Legajo').val());
            let objeto:Persona.empleado = new empleado(nombre, apellido, edad, horario,legajo);
            let index:number;
            for(let j= 0; j<manejadora.empleados.length;j++){
                if(i == manejadora.empleados[j].legajo){
                    
                   index = j;
                    
                }
            }
            
            console.log(index);
            $('#btnAgregar').click(function (){
                manejadora.empleados.splice(index,1,objeto);                
                localStorage.setItem('listaEmpleados',JSON.stringify(manejadora.empleados));
            });
        }
        static eliminar(i:number):void{
            manejadora.empleados = JSON.parse(localStorage.getItem('listaEmpleados'));
            
            for(let j= 0; j<manejadora.empleados.length;j++){
                if(i == manejadora.empleados[j].legajo){
                    manejadora.empleados.splice(j,1);
                    localStorage.setItem('listaEmpleados',JSON.stringify(manejadora.empleados));
                }
            }
            manejadora.mostrarEmpleados();
            
        }
        filtrarPorHorario():void{}
        promedioEdadPorHorario():void{}
    }
}


