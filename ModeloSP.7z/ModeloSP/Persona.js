var Persona;
(function (Persona) {
    var persona = /** @class */ (function () {
        function persona(nombre, apellido, edad) {
            if (nombre != undefined) {
                this.nombre = nombre;
            }
            if (apellido != undefined) {
                this.apellido = apellido;
            }
            if (edad != undefined) {
                this.edad = edad;
            }
        }
        persona.prototype.personaToJson = function () {
            return JSON.stringify(this);
        };
        return persona;
    }());
    Persona.persona = persona;
})(Persona || (Persona = {}));
