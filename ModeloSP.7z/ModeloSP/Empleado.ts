namespace Persona{
    export class empleado extends persona{
        horario:string;
        legajo:number;

        constructor(nombre:string,apellido:string,edad:number,horario:string, legajo:number){
            super(nombre, apellido,edad);
            if(legajo != undefined){
                this.legajo = legajo;
            }
            if(horario != undefined){
                this.horario =  horario;
            }
        }

        empleadoToJson():string{
            return JSON.stringify(this);
        }
    }
}