var materias;
$(document).ready(function(){
    //mostrarFormulario(true);
    //mostrarSpinner(true);
    $.get("http://localhost:3000/materias",function(data,status){
        if(status != "error"){
            materias = data;
            /* var datos = JSON.parse(data);
            console.log(datos); */
            cargar (data);
        }
        else{
            console.log("ERROR"+status);
        }
    });

});

function cargar(respuesta){
    $('#detalleBackground').append('<table></table>');
    $('table').append('<thead></thead>');
    var tituloNombre = $('<th></th>').text("Nombre");
    var tituloCuatri = $('<th></th>').text("Cuatrimestre");
    var tituloFecha = $('<th></th>').text("Fecha Final");
    var tituloTurno = $('<th></th>').text("Turno");
    $('thead').append(tituloNombre,tituloCuatri,tituloFecha,tituloTurno);
    var cuerpoTabla = $('<tbody></tbody>').attr("id","cuerpoTabla");
    $('table').append(cuerpoTabla);
    for(var i = 0; i<respuesta.length;i++){ 
        var objeto = respuesta[i];
        //console.log(objeto);
        var columnas = Object.keys(objeto);
        var fila = $("<tr></tr>").attr("id","fila");
        $("#cuerpoTabla").append(fila);
        fila.dblclick(function(event){
            $("#contenedor").show();
            event.preventDefault();
            node = event.currentTarget;
            fila = node.children;
            console.log(materias[0].id);
            var indice = BuscaIndice(materias[0].id,materias); 
            
            localStorage.setItem("indice",indice);
            $("#Nombre").val(fila[0].innerHTML);
            $("#Cuatrimestre").val(fila[1].innerHTML);
            var fecha = (fila[2].innerHTML).split("/");
            $('#Date').val(fecha[2]+"-"+fecha[1]+"-"+fecha[0]);
            if(fila[3].innerHTML == "Mañana"){
                $("#Mañana").prop( "checked", true );
            }
            else{
                $("#Noche").prop("checked" , true);
            }
        });
        for(j = 1; j < 5; j++){
                var celda = $("<td></td>").text(objeto[columnas[j]]);
                fila.append(celda);
        }
    }
}

function BuscaIndice(id,array){
    
    var retorno = -1;
    for(i=0;i<array.length;i++){
        
        if(id == ""+array[i].id){
            
            retorno = i;
        }
    }
    return retorno;
}

function cerrar(){
    $("#contenedor").hide();
}

function autocompletar(){
    console.log(materias);
    $("#spinner").hide();
    var index = localStorage.getItem("indice");
    //console.log(($("#Nombre").val()).length);
    if(($("Nombre").val() == "" || ($("#Nombre").val()).length < 6)){
        $("#Nombre").removeClass("sinError");
        $("#Nombre").addClass("Error");
        return;
    }
        else{
            //materias[index].id = materias[index].id;
            materias[index].nombre = $("#Nombre").val();
            materias[index].fecha = $("#Date").val();
            materias[index].cuatrimestre = $('#Cuatrimestre').val();

        if($("#Mañana").is(":checked") == true){
            materias[index].turno = "Mañana";
        }
        else{
            materias[index].turno = "Noche";
        }
        
        $("#spinner").show(); 
        $.post("http://localhost:3000/editar",{
            "id":materias[index].id,
            "nombre":materias[index].nombre,
            "cuatrimestre": materias[index].cuatrimestre,
            "fechaFinal":materias[index].fecha,
            "turno":materias[index].turno
        },function (data,status) {
            $("#spinner").hide();  
            if(data.type == "ok"){
                alert("Se modificó correctamente.");
                location.reload();
                 
            }
            else{
                alert('ERROR');
                //Cargar();
            }                            
        });
        $("#form").hide();
    }
}

function eliminar(){
    $("#spinner").hide();
    var index = localStorage.getItem("indice");
    $.post("http://localhost:3000/eliminar",{
            "id":materias[index].id
        },function (data,status) {
            $("#spinner").hide();  
            if(data.type == "ok"){
                alert("Se modificó correctamente.");
                location.reload();
            }
            else{
                alert('ERROR');
                //Cargar();
            }                            
        });
        $("#form").hide();  
}