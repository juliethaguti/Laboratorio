var xhr = new XMLHttpRequest();
var xhttp = new XMLHttpRequest();

window.addEventListener("load", function(){
    xhr.open("GET","http://localhost:3000/personas",true);//true para que sea asincrono, por defecto es asincrono
    xhr.onreadystatechange = getPersonas;
    xhr.send(); //La información por GET, viaja por la URL, se agrega en la URL
    abrir(false);
});

/*function $(id){
    return document.getElementById(id);
}*/

function agregar(){ 
    abrir(true);
    limpiar();
}

function abrir(mostrar){
    var contAgregar = document.getElementById("contenedor");
    var btnAgregar = document.getElementById("btnAgregar");
    var Spinner = document.getElementById("spinner");
    btnAgregar.hidden = mostrar;
    Spinner.hidden = !mostrar;
    contAgregar.hidden = !mostrar;
}

function guardar(){
    //var nombre = $("Nombre").value;
    //var apellido = $("Apellido").value;
    var nombre = document.getElementById("Nombre").value;
    var apellido  = document.getElementById("Apellido").value;
    var telefono = document.getElementById("Telefono").value;
    var fecha = document.getElementById("Fecha").value;

    if(apellido == "" || nombre == "")
    {
        document.getElementById("Nombre").className="conError";
        document.getElementById("Apellido").className="conError";
        alert("Debe ingresar un nombre y un apellido");
    }
    else{
        var respuesta = confirm("Esta seguro que desea agregar a un persona?");
        if(respuesta == true)
        {
            document.getElementById("Nombre").className="sinError";
            document.getElementById("Apellido").className="sinError";
            var tCuerpo = document.getElementById("cuerpoTabla");

            tCuerpo.innerHTML = tCuerpo.innerHTML +
            "<tr><td>"+nombre+"</td><td>"+apellido+"</td><td><a href='' onclick='Borrar(event)'></a></td><td><a href=''onclick='Editar(event)'></a></td></tr>";
            cerrar();   
        }
    }
    var parametros = {"nombre" : nombre, "apellido" : apellido, "telefono" : telefono, "fecha" : fecha};

    xhttp.open("POST","http://localhost:3000/nuevaPersona");
    xhttp.onreadystatechange = callback;
    xhttp.setRequestHeader("Content-Type","application/json");
    xhttp.send(JSON.stringify(parametros));
}

function cerrar(){
    abrir(false);
}

function limpiar(){
    document.getElementById("Nombre").value="";
    document.getElementById("Apellido").value="";
}

function getPersonas(){
    if(xhr.readyState === 4){
       
        if(xhr.status === 200){
            var respuesta = 
            xhr.responseText;
            if(respuesta != ""){
                var arrayPersonas=JSON.parse(respuesta);
                agregarAGrilla(arrayPersonas);
            }
        }
    }
       
    
}

function agregarAGrilla(array){
    
    var tabla = "";
    var count = array.length;
    for(var i = 0; i<count;i++){
        tabla += "<tr><td>";
        tabla += array[i].nombre;
        tabla += "</td><td>";
        tabla += array[i].apellido;
        tabla += "</td><td>";
        tabla += array[i].telefono;
        tabla += "</td><td>";
        tabla += array[i].fecha;
        tabla += "</td><td><a href='' onclick='Borrar(event)'>Borrar</a> <a href=''onclick='Editar(event)'>Editar</a>";
        tabla += "</td></tr>"
    }
    document.getElementById("cuerpoTabla").innerHTML = tabla;
}

function Borrar(e){
    //propiedad target: cual fue el elemento que ejecuto el evento.
    e.preventDefault(); //Para que me deje acceder a los hijos, sacar el valor por defecto.
    console.log(e.target);
    console.log(e.target.parentNode);
    console.log(e.target.parentNode.parentNode);

    e.target.parentNode.parentNode.innerHTML="";
}

function Editar(e){
    e.preventDefault();
    var nombre = e.target.parentNode.parentNode.children[0].innerHTML;
    var apellido = e.target.parentNode.parentNode.children[1].innerHTML;
    document.getElementById('Nombre').value = nombre;
    document.getElementById('Apellido').value = apellido;
    abrir(true);
    guardar();
}

function callback(){
    if(xhttp.readyState===4){
        if(xhttp.status===200){
            var respuesta = xhttp.responseText;
            if(respuesta == "ok"){
                alert("login ok")
            }
            else if(respuesta == "error"){
                alert("Usuario o contraseña incorrectos")
            }
            else{
                alert(respuesta);
            }
        }      
    }
}
//Para pasarlo al servidor lo pasamos de json a string con stringfy, para recibirlo del servidor json.parse para pasarlo de string a json
// ChildNodes array de elementos que pueden ser element_node o text_node. Para crear document.createTextNode("textoAInsertar") o document.createElement("tagACrear").
//appendChild para agregar un hijo y relacionar los nodo texto a sus padres. Ejemplo: elemento.appendChild(hijo)