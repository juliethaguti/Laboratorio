var xhr = new XMLHttpRequest();

xhr.open("GET","parametros",true);
xhr.send();//Si es GET, los parametros se pasan por la ruta
xhr.send("string")//Si es POST, los parametros se pasan por el cuerpo

//Levantar api node index.js parado en el api

