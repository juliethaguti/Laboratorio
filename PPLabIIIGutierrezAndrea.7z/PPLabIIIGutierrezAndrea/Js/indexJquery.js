var personas;
$(document).ready(function(){
    $.get("http://localhost:3000/personas",function(data, status){
        $("#spinner").hide();
        console.log(status);
        personas = data
        agregarACuerpo(data);
    });
});

function agregarACuerpo(array){
    $("#cards").attr("class", "cards");
    for(var i = 0; i<array.length;i++){
        var contenedor = $("<div></div>").attr("class","card");
        contenedor.dblclick(function(event){
            $("#form").show();
            event.preventDefault();
            fila = event.currentTarget.lastChild.children;
            //sessionStorage.setItem("card",fila);
            var indice = BuscaIndice((fila[0]).value,array); 
            localStorage.setItem("indice",indice);
            $("#txtNombre").val(fila[1].innerHTML);
            $("#txtApellido").val(fila[2].innerHTML);
            if(fila[3].innerHTML == "Female"){
                $("#Femenino").prop( "checked", true );
            }
            else{
                $("#Masculino").prop("checked" , true);
            }
        });
        var objeto = array[i]; 
        var columnas = Object.keys(objeto);
        $("#cards").append(contenedor);
        var imag = $("<img>").attr("src","../Img/user.png");
        var infoTarjeta = $("<div></div>").attr("id","infoTarjeta");
        contenedor.append(imag,infoTarjeta);

        for(j = 0; j < columnas.length; j++){
            if(j == 0){
                var hidden = $("<input>").attr({
                    "id" : "idTarjetas",
                    "type" : "hidden",
                    "value" : objeto[columnas[j]]
                });
                infoTarjeta.append(hidden)
            }
            else{
                var label = $("<label></label>").text(objeto[columnas[j]]);
                infoTarjeta.append(label);
            }
        }        
    }
}

function Guardar(){
    $("#spinner").hide();
    var indexAlumno = localStorage.getItem("indice");
    //var personas = localStorage.getItem("personas");
    if($("#txtNombre").val() == "" || ($("#txtNombre").val()).length < 3){
        $("#txtNombre").addClass("Error");
    }
    else if($("#txtApellido").val() == "" || ($("#txtApellido").val()).length < 3){
        $("#txtApellido").addClass("Error");
    }
    else{
        personas[indexAlumno].nombre = $("#txtNombre").val();
        personas[indexAlumno].apellido = $("#txtApellido").val();
        if($("#Femenino").is(":checked") == true){
            personas[indexAlumno].sexo = "Female";
        }
        else{
            personas[indexAlumno].sexo = "Male";
        }
        $("#spinner").show(); console.log(personas[0]);
        $.post("http://localhost:3000/editar",personas[indexAlumno],function (data,status) {
            $("#spinner").hide();
            var respuesta = data;            
                    
            if(respuesta.type == "error"){
                 alert(respuesta.message);
            }
            else{
                alert("Se modificó correctamente.");
                location.reload();
                Cargar();
            }                            
        });
        $("#form").hide();
    }
}

function eliminar(){
    var indexAlumno = localStorage.getItem("indice");
    var id = personas[indexAlumno].id;
    var envio = { id: id };
    
    $.post("http://localhost:3000/eliminar",envio,function (data,status) {
        $("#spinner").hide();            
        if(data.type == "ok"){
            alert("Item eliminado");
            location.reload();
            Cargar()    
        }                            
    });
    cerrar();
}

function BuscaIndice(id,array){
    var retorno = -1;
    for(i=0;i<array.length;i++){
    
        if(id == array[i].id){
            retorno = i;
            break;
        }
    }
    console.log(retorno);
    return retorno;
}

function cerrar(){
    $("#form").hide();
}