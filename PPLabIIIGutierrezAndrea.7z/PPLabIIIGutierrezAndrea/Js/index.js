var xhr = new XMLHttpRequest();
var httpReq = new XMLHttpRequest();

window.addEventListener("load",Cargar);

function Cargar(){
    localStorage.clear();
    xhr.open("GET","http://localhost:3000/personas",true);
    xhr.onreadystatechange = callback;
    xhr.send(); 
}
function callback(){
    document.getElementById("spinner").hidden=false;
    if(xhr.readyState === 4 && xhr.status === 200){
        document.getElementById("spinner").hidden=true;
        var respuesta = JSON.parse(xhr.responseText);
       
        //localStorage.setItem(respuesta);
        localStorage.setItem("personas",xhr.responseText);
        agregarACuerpo(respuesta);
    }
    else{
    console.log("ERROR "+xhr.status);
    }
}

function agregarACuerpo(array){
    var cards = document.getElementById("cards");
    cards.setAttribute("class", "cards")
    for(var i = 0; i<array.length;i++){
        var contenedor = document.createElement("div");
        contenedor.setAttribute("class","card");
        contenedor.ondblclick = editar;
        var objeto = array[i];
        var columnas = Object.keys(objeto);
        cards.appendChild(contenedor);
        var imag = document.createElement("img");
        imag.setAttribute("src","Img/user.png");
        contenedor.appendChild(imag);
        var infoTarjeta = document.createElement("div");
        contenedor.appendChild(infoTarjeta);

        for(j = 0; j < columnas.length; j++){
            
            if(j == 0){
                var hidden = document.createElement("input");
                //console.log(infoTarjeta);            
                infoTarjeta.appendChild(hidden);
                hidden.setAttribute("type","hidden");
                infoTarjeta.setAttribute("id","txtTarjetas");
                //var Txt=document.createTextNode();
                hidden.setAttribute("value",objeto[columnas[j]]);
                hidden.setAttribute("id","txtHidden");
                var valor = hidden.value;
            }
            else{
                var label = document.createElement("label");
                infoTarjeta.appendChild(label);
                var textoCelda = document.createTextNode(objeto[columnas[j]]);
                label.appendChild(textoCelda);
            }
        }        
    }
}

    function editar(i){
        document.getElementById("form").hidden = false;
        i.preventDefault();
        fila = i.target.lastChild.children;
        sessionStorage.setItem("card",fila);
        var indice = BuscaIndice((fila[0]).value);
        localStorage.setItem("indice",indice);
        document.getElementById("txtNombre").value = fila[1].innerHTML;
        document.getElementById("txtApellido").value = fila[2].innerHTML;
        if(fila[3].innerHTML == "Female"){
            document.getElementById("Femenino").checked = true;
            document.getElementById("Masculino").checked = false;
        }
        else{
            document.getElementById("Masculino").checked = true;
            document.getElementById("Femenino").checked = false;
        }
    }

    function Guardar(){
        var spinner = document.getElementById("spinner").hidden=false;
        var indexAlumno = localStorage.getItem("indice");
        var personas = JSON.parse(localStorage.getItem("personas"));
        var nombre = document.getElementById("txtNombre").value; 
        var apellido = document.getElementById("txtApellido").value;
        if(nombre == "" || nombre.length < 3){
            document.getElementById("txtNombre").className = "Error";
        }
        else if(apellido == "" || apellido.length < 3){
            document.getElementById("txtApellido").className = "Error";
        }
        else{
            personas[indexAlumno].nombre = nombre;
            personas[indexAlumno].apellido = apellido;
            if(document.getElementById("Femenino").checked == true){
                personas[indexAlumno].sexo = "Female";
            }
            else{
                personas[indexAlumno].sexo = "Male";
            }
            spinner.hidden = false;
            httpReq.open("POST","http://localhost:3000/editar",true);
            httpReq.onreadystatechange = callBackMod;
            httpReq.setRequestHeader("Content-Type","application/json");
            httpReq.send(JSON.stringify(personas[indexAlumno]));
            document.getElementById("form").hidden = true;
        }
    }

    function BuscaIndice(id){
        var notas = JSON.parse(localStorage.getItem("personas"));
        var retorno = -1;
        for(i=0;i<notas.length;i++){
            if(id == notas[i].id){
                retorno = i;
                break;
            }
        }
        console.log(retorno);
        return retorno;
    }

    function cerrar(){
        document.getElementById("form").hidden = true;
    }

    var callBackMod = function () {
        var spinner = document.getElementById("spinner").hidden=false;
        if (httpReq.readyState === 4) {       
            if (httpReq.status == 200) {
                spinner.hidden = true;
                console.log(httpReq.responseText);
                var respuesta = JSON.parse(httpReq.responseText);            
                
                if(respuesta.type == "error"){
                    alert(respuesta.message);
                }
                else{
                    alert("Se modificó correctamente.");
                    location.reload();
                    Cargar();
                }                            
            }
            else {
                console.log("Ocurrió un error en el servidor. Código: " + httpReq.status);
            }
        }
    }
    function eliminar(){
        //var id = document.getElementById("Id").value;
        var personas = JSON.parse(localStorage.getItem("personas"));
        var indexAlumno = localStorage.getItem("indice");
        var id = personas[indexAlumno].id;
        var envio = { id: id };
        
        xhr.open("POST","http://localhost:3000/eliminar",true);
        xhr.setRequestHeader("Content-type","application/json");
        xhr.onreadystatechange = callbackEliminar;
        xhr.send(JSON.stringify(envio));
        cerrar();
    }
    
    function callbackEliminar(){
        document.getElementById("spinner").hidden=false;
        if(xhr.readyState === 4 && xhr.status === 200){
            var respuesta = xhr.responseText;
            var tipoRespuesta = JSON.parse(respuesta)["type"];
            console.log(tipoRespuesta);
            if(tipoRespuesta == "ok"){
                alert("Item eliminado");
                location.reload();
                /* var filaFormulario = sessionStorage.getItem("card");
                console.log(filaFormulario);filaFormulario.parentNode.removeChild(filaFormulario); */
            }
        }
        else{
            console.log("ERROR"+xhr.status);
        }
    }  