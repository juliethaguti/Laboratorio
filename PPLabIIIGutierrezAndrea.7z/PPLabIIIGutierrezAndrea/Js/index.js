var xhr = new XMLHttpRequest();
var httpReq = new XMLHttpRequest();

window.addEventListener("load",function(){
    //document.getElementById("contenedor").hidden = true;
    //document.getElementById("titulo").hidden = true;
    Cargar();
});

function Cargar(){
    xhr.open("GET","http://localhost:3000/personas",true);
    xhr.onreadystatechange = callback;
    xhr.send(); 
}
function callback(){
    document.getElementById("spinner").hidden=false;
    if(xhr.readyState === 4 && xhr.status === 200){
        document.getElementById("spinner").hidden=true;
        var respuesta = JSON.parse(xhr.responseText);
       
        //localStorage.setItem(respuesta);
        localStorage.setItem("personas",xhr.responseText);
        agregarACuerpo(respuesta);
    }
    else{
    console.log("ERROR "+xhr.status);
    }
}

function agregarACuerpo(array){
    var cards = document.getElementById("cards");
    cards.setAttribute("class", "cards")
    for(var i = 0; i<array.length;i++){
        var contenedor = document.createElement("div");
        contenedor.setAttribute("class","card");
        contenedor.ondblclick = editar;
        var objeto = array[i];
        var columnas = Object.keys(objeto);
        cards.appendChild(contenedor);
        var imag = document.createElement("img");
        imag.setAttribute("src","Img/user.png");
        contenedor.appendChild(imag);
        var infoTarjeta = document.createElement("div");
        contenedor.appendChild(infoTarjeta);

        for(j = 0; j < columnas.length; j++){
            
            if(j == 0){
                var hidden = document.createElement("input");
                //console.log(infoTarjeta);            
                infoTarjeta.appendChild(hidden);
                hidden.setAttribute("type","hidden");
                infoTarjeta.setAttribute("id","txtTarjetas");
                //var Txt=document.createTextNode();
                hidden.setAttribute("value",objeto[columnas[j]]);
                hidden.setAttribute("id","txtHidden");
                var valor = hidden.value;
            }
            else{
                var label = document.createElement("label");
                infoTarjeta.appendChild(label);
                var textoCelda = document.createTextNode(objeto[columnas[j]]);
                label.appendChild(textoCelda);
            }
        }        
    }
}

    function editar(i){
        document.getElementById("form").hidden = false;
        i.preventDefault();
        fila = i.target.lastChild.children;
        //console.log(fila);
        //var indice = BuscaIndice(parseInt((fila[0]).innerHTML));
        console.log(fila);
        //sessionStorage.setItem("indice",indice);
        document.getElementById("txtNombre").value = fila[1].innerHTML;
        document.getElementById("txtApellido").value = fila[2].innerHTML;
        /* if(fila[3].innerHTML == "Female"){
            document.getElementById("Femenino").checked = true;
        }
        else{
            document.getElementById("Masculino").checked = false;
        } */
    }

    function Guardar(){
        var indexAlumno = sessionStorage.getItem("indice");
        var notas = JSON.parse(localStorage.getItem("notas"));
        notas[indexAlumno].legajo = document.getElementById("txtLegajo").value;
        notas[indexAlumno].nombre = document.getElementById("txtNombre").value;
        notas[indexAlumno].materia = document.getElementById("txtMateria").value;
        notas[indexAlumno].nota = document.getElementById("txtNota").value;
    
        spinner.hidden = false;
        httpReq.open("POST","http://localhost:3000/editarNota");
        httpReq.onreadystatechange = callBackMod;
        httpReq.setRequestHeader("Content-Type","application/json");
        httpReq.send(JSON.stringify(notas[indexAlumno]));
        document.getElementById("contenedor").hidden = true;
    }

    function BuscaIndice(id){
        var notas = JSON.parse(localStorage.getItem("notas"));
        var retorno = -1;
        for(i=0;i<notas.length;i++){
            if(id == notas[i].id){
                retorno = i;
                break;
            }
        }
        return retorno;
    }

    function cerrar(){
        document.getElementById("form").hidden = true;
    }