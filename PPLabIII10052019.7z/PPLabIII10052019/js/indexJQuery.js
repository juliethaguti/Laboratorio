$(document).ready(function(){
    //mostrarFormulario(true);
    //mostrarSpinner(true);
    $.get("http://localhost:3000/materias",function(data,status){
        if(status != "error"){
            //var datos = JSON.parse(data);
            //console.log(datos);
            cargar (data);
        }
        else{
            console.log("ERROR"+status);
        }
    });

});

function cargar(respuesta){
    $('detalleBackground').append('<table></table>');
    $('table').append('<thead></thead>');
    var tituloNombre = $('<th></th>').text("Nombre");
    var tituloCuatri = $('<th></th>').text("Cuatrimestre");
    var tituloFecha = $('<th></th>').text("Fecha Final");
    var tituloTurno = $('<th></th>').text("Turno");
    $('thead').append(tituloNombre,tituloCuatri,tituloFecha,tituloTurno);

}
    //$("#btnCerrar").clicK()


/*
Selectores:
$("p") Seleccionar elementos por su etiqueta
$("#primero") Seleccionar elementos por su IDBCursor.
$(".importante")Seleccionar elementos por su clase
$("p[name=primero]") Seleccionar elementos por su atributo

Guardar una selección en una variable
var parrafos = $("p"); Guarda los elementos en el momento


filtrado de selecciones
.has: opera sobre elementos que contienen otros elementos incluidos en el has
$("div.parrafos").has("p"); Devuelve div.parrafos
.not: opera sobre los elementos que no contienen otros elementos indicado en el has
$("p").not(".importante"); Devuelve párrafos sin clase imporatante
.filter: opera en elementos que coinciden con la busqueda
$("p").filter(".importante") Devuelve p con clase importante
.find: devuelve descendientes de un elemento
$("p#primero").find("span"); Devuelve los span del p#primero

.first, .last: Devuelve el primer o último elmento de una lista
$("p").first(); Devuelve el primer párrafo
.eq(numero); Devuelve el elemento que coincide con la posición indicada
$("p").eq(5); Devuelve el sexto párrafo

Encadenamiento de selecciones
$("div#textos").find("p").eq(0)

Extraer información de un elemento: paréntesis sin parámetros
console.log($("p#primero").html()); Extraigo código html
console.log($("p#primero").text()), Extraigo texto
console.log($(input).val())  Extraifo el valor de un input

Modificar o añadir informacion de un elemento: valor entre paréntesis
$("p#primero").html("Nuevo valor del párrafo"); Introducir código html
$("p#primero").text("Nuevo valor del párrafo"); Introducir texto
$("input").val("Nuevo valor del input"); Introducir un valor en el input

Extraer información de un atributo
console.log($("a").attr("href"));

Modificar o añadir información de un atributo
$("a").attr("href","todoslosenlaces.html");
Varios atributos
$("a").attr({
    "tittle":"Todos los enlaces",
    "href":"todoslosenlaces2.html"
});

$.ajax({
url: //donde realizamos la petición.
data: (parámetros) //Datos a enviar, como objeto o cadena.
success: function (respuesta){//Función si la petición ha ido bien
//mostrar respuesta},
error: function(xhr, status){//Función si la petición ha fallado},
complete: function(xhr, status){//Función si la petición ha sido completada}
}); 

//Otros métodos basados en $.ajax pero tienen parámetros establecidos por defecto
//GET
$("enviarGet").click(function(){
    $.get(url,data(parametros),function(respuesta){//mostrar respuesta});
}).fail(function(){

});
//POST
$("enviarPost").click(function (){
    //Función que envia datos y no devuelve nada
    $.post(url,data);
    // Función que no envía datos pero recibe respuesta
    $.post(url,function(respuesta){

    });
    //Función que envía datos y recibe respuesta
    $.post(url,data).done(function(respuesta){

    });
});

*/