var xhr = new XMLHttpRequest();

window.addEventListener("load",function(){
    mostrarFormulario(true);
    mostrarSpinner(true);
    xhr.open("GET","http://localhost:3000/materias",true);
    xhr.onreadystatechange = callback;
    xhr.send();
    var btnCerrar = document.getElementById("btnCerrar");
    btnCerrar.addEventListener("click",cerrar);
    var bntModificar = document.getElementById("btnModificar");
    bntModificar.addEventListener("click",modificar);
    var btnEliminar = document.getElementById("btnEliminar");
    btnEliminar.addEventListener("click",eliminar);
});

function callback(){
    if(xhr.readyState === 4 && xhr.status === 200){

        var respuesta = xhr.responseText;
        var array = JSON.parse(respuesta);
        cargar(array);
    }
    else{
        console.log("ERROR"+xhr.status);
    }
}

function cargar(respuesta){
    var tabla = document.createElement("table");
    document.getElementById("detalleBackground").appendChild(tabla);
    var cabezaTabla = document.createElement("thead");
    tabla.appendChild(cabezaTabla);
    var nombreTitulo = document.createElement("th");
    cabezaTabla.appendChild(nombreTitulo);
    nombreTitulo.appendChild(document.createTextNode("Nombre"));
    var cuatriTitulo = document.createElement("th");
    cabezaTabla.appendChild(cuatriTitulo);
    cuatriTitulo.appendChild(document.createTextNode("Cuatrimestre"));
    var fechaF = document.createElement("th");
    cabezaTabla.appendChild(fechaF);
    fechaF.appendChild(document.createTextNode("Fecha Final"));
    var turnoTitulo = document.createElement("th");
    cabezaTabla.appendChild(turnoTitulo);
    turnoTitulo.appendChild(document.createTextNode("Turno"));
    var cuerpoTabla = document.createElement("tbody");
    tabla.appendChild(cuerpoTabla);
    var count = respuesta.lenght;
    
    for(var i = 0; i<14;i++){
        var fila = document.createElement("tr");
        cuerpoTabla.appendChild(fila);
        fila.addEventListener("dblclick",autocompletar);
        var columnaId = document.createElement("td");
        columnaId.setAttribute("style","display:none");
        //fila.setAttribute("id",respuesta[i].id);
        fila.appendChild(columnaId);
        var id = document.createTextNode(respuesta[i].id);
        columnaId.appendChild(id);
        var columna = document.createElement("td");
        fila.appendChild(columna);
        var nombre = document.createTextNode(respuesta[i].nombre);
        columna.appendChild(nombre);
        var columnaCuatri = document.createElement("td");
        fila.appendChild(columnaCuatri);
        var cuatrimestre = document.createTextNode(respuesta[i].cuatrimestre);
        columnaCuatri.appendChild(cuatrimestre);
        var columnaFecha = document.createElement("td");
        fila.appendChild(columnaFecha);
        var fechaFinal = document.createTextNode(respuesta[i].fechaFinal);
        columnaFecha.appendChild(fechaFinal);
        var columnaTurno = document.createElement("td");
        fila.appendChild(columnaTurno);
        var turno = document.createTextNode(respuesta[i].turno);
        columnaTurno.appendChild(turno);
    }
}

var filaFormulario;
function autocompletar(event){
    filaFormulario = event.target.parentNode;
    var hijos = event.target.parentNode.children;
    
    document.getElementById("Id").value = hijos[0].innerText;
    document.getElementById("Nombre").value = hijos[1].innerText;
    document.getElementById("Cuatrimestre").value = hijos[2].innerText;
    document.getElementById("Cuatrimestre").disabled = true;
    document.getElementById("Date").value = fechaValue(hijos[3].innerText);
    var turno = hijos[4].innerHTML;
    if(turno === "Mañana"){
        document.getElementById("Mañana").checked = true;
        document.getElementById("Noche").checked = false;
    }
    else if(turno === "Noche"){
        document.getElementById("Noche").checked = true;
        document.getElementById("Mañana").checked = false;
    }
    mostrarFormulario(false);
}

function mostrarFormulario(mostrar){
    var Formulario = document.getElementById("contenedor");
    Formulario.hidden = mostrar;
}

function mostrarSpinner(mostrar){
    var spinner = document.getElementById("imgLoading");
    spinner.hidden = mostrar;
}

function cerrar(){
    mostrarFormulario(true);
}

function fechaValue(fecha){  
    var date = fecha.split("/");
    return date[2]+"-"+date[1]+"-"+date[0]; 
}

function modificar(){
    var id = document.getElementById("Id").value;
    var nombre = document.getElementById("Nombre").value;
    var cuatrimestre = document.getElementById("Cuatrimestre").value;
    var fecha = document.getElementById("Date").value.split("-");
    var turno;
    if(document.getElementById("Mañana").checked == true){
        turno = document.getElementById("Mañana").value;
    }else{ //if(document.getElementById("Noche").checked == true){
        turno = document.getElementById("Noche").value;
    }
    var nuevaFecha = fecha[2]+"/"+fecha[1]+"/"+fecha[0];
    var objeto = {id: id, nombre: nombre, cuatrimestre: cuatrimestre, fechaFinal: nuevaFecha, turno: turno}
    console.log(objeto);

    xhr.open("POST","http://localhost:3000/editar",true);
    xhr.setRequestHeader("Content-type","application/json");
    xhr.onreadystatechange = callbackModificar;
    xhr.send(JSON.stringify(objeto));
}

function callbackModificar(){
    mostrarSpinner(false);
    if(xhr.readyState === 4 && xhr.status === 200){

        var respuesta = xhr.responseText;
        var tipoRespuesta = JSON.parse(respuesta)["type"];
        console.log(tipoRespuesta);
        if(tipoRespuesta == "ok"){
            var hijos = filaFormulario.children;
            hijos[0].innerText = document.getElementById("Id").value;
            hijos[1].innerText = document.getElementById("Nombre").value;
            hijos[2].innerText = document.getElementById("Cuatrimestre").value;
            var fecha = document.getElementById("Date").value.split("-");
            hijos[3].innerText = fecha[2]+"/"+fecha[1]+"/"+fecha[0];
            if(document.getElementById("Mañana").checked == true){
                hijos[4].innerText = document.getElementById("Mañana").value;
            }
            else{
                hijos[4].innerText = document.getElementById("Noche").value;
            }
        }
    }
    else{
        console.log("ERROR"+xhr.status);
    }
    mostrarSpinner(true);
}

function eliminar(){
    var id = document.getElementById("Id").value;
    var envio = { id: id };
    xhr.open("POST","http://localhost:3000/eliminar",true);
    xhr.setRequestHeader("Content-type","application/json");
    xhr.onreadystatechange = callbackEliminar;
    xhr.send(JSON.stringify(envio));
}

function callbackEliminar(){
    if(xhr.readyState === 4 && xhr.status === 200){

        var respuesta = xhr.responseText;
        var tipoRespuesta = JSON.parse(respuesta)["type"];
        console.log(tipoRespuesta);
        if(tipoRespuesta == "ok"){
            filaFormulario.parentNode.removeChild(filaFormulario);
        }
    }
    else{
        console.log("ERROR"+xhr.status);
    }
}