var personas;
$(document).ready(function(){
    $("#contenedor").hide();
    $("#titulo").hide();
    $.get("http://localhost:3000/personas",function(data, status){
        $("#spinner").hide();
        personas = data;
        agregarAGrilla(data, data.type);
        //console.log(data);
    });
    completarProvincias();
});

function agregarAGrilla(array, tipoUsuario){
    
    for(var i = 0; i<array.length;i++){ 
        var objeto = array[i];
        var columnas = Object.keys(objeto);
        var fila = $("<tr></tr>").attr("id","fila");
        $("#cuerpoTabla").append(fila);
        fila.dblclick(function(event){
            $("#form").show();
            event.preventDefault();
            node = event.currentTarget;
            fila = node.children;
            //console.log((fila[0]));
            //console.log((fila[0].firstChild));
            var indice = BuscaIndice((fila[0]).firstChild.textContent,array); 
            localStorage.setItem("indice",indice);
            $("#txtNombre").val(fila[1].innerHTML);
            $("#txtApellido").val(fila[2].innerHTML);
            if(fila[3].innerHTML == "Female"){
                $("#Femenino").prop( "checked", true );
            }
            else{
                $("#Masculino").prop("checked" , true);
            }
        });
        for(j = 0; j < 5; j++){
            
            if(j == 3){
                var localidad = Object.keys(objeto);
                //console.log(localidad);
                var celda = $("<td></td>").text(objeto.localidad.nombre);
                fila.append(celda);
            }
            else{
                var celda = $("<td></td>").text(objeto[columnas[j]]);
                fila.append(celda);
            }
        }
    }
}

function Guardar(){
    $("#spinner").hide();
    var indexAlumno = localStorage.getItem("indice");
    if(($("#txtNombre").val() == "" || ($("#txtNombre").val()).length < 3) && ($("#txtApellido").val() == "" || ($("#txtApellido").val()).length < 3)){
        $("#txtNombre").addClass("Error");
        $("#txtApellido").addClass("Error");
    }
    else if($("#txtNombre").val() == "" || ($("#txtNombre").val()).length < 3){
        $("#txtNombre").addClass("Error");
    }
    else if($("#txtApellido").val() == "" || ($("#txtApellido").val()).length < 3){
        $("#txtApellido").addClass("Error");
    }
    else{
        personas[indexAlumno].id = personas[indexAlumno].id;
        personas[indexAlumno].nombre = $("#txtNombre").val();
        personas[indexAlumno].apellido = $("#txtApellido").val();

        if($("#Femenino").is(":checked") == true){
            personas[indexAlumno].sexo = "Female";
        }
        else{
            personas[indexAlumno].sexo = "Male";
        }
        var localidad = { "id" : 17,"nombre":$('#selectLocalidad').val()};
        
        $("#spinner").show(); 
        $.post("http://localhost:3000/editar",{
            "id":personas[indexAlumno].id,
            "nombre":personas[indexAlumno].nombre,
            "apellido": personas[indexAlumno].apellido,
            "sexo":personas[indexAlumno].sexo,
            "localidad":JSON.stringify(localidad)
        },function (data,status) {
            $("#spinner").hide();  
            if(data.type == "error"){
                 alert('ERROR');
            }
            else{
                alert("Se modificó correctamente.");
                location.reload();
                //Cargar();
            }                            
        });
        $("#form").hide();
    }
}

function BuscaIndice(id,array){
    
    var retorno = -1;
    for(i=0;i<array.length;i++){
        
        if(id == ""+array[i].id){
            
            retorno = i;
        }
    }
    return retorno;
}

function cerrar(){
    $("#form").hide();
}

function completarProvincias(){
    $.get("http://localhost:3000/provincias",function(data, status){
        $("#spinner").hide();
        agregarASelect(data);
       
    });
}

function agregarASelect(data){
    for(var i = 0; i<data.length;i++){ 
        var objeto = data[i];
        console.log(objeto);
        var option = $("<option></option>").attr("value",objeto.nombre);
        $('#selectProvincia').append(option);
        option.text(objeto.nombre);
    }
}