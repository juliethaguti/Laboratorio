var personas;
$(document).ready(function(){
    $("#contenedor").hide();
    $("#titulo").hide();
    $.get("http://localhost:3000/personas",function(data, status){
        $("#spinner").hide();
        personas = data;
        agregarAGrilla(data, data.type);
        //console.log(data);
    });
});

function agregarAGrilla(array, tipoUsuario){
    //var cuerpoTabla = document.getElementById("cuerpoTabla");
    for(var i = 0; i<array.length;i++){
        //var fila =  
        var objeto = array[i];
        var columnas = Object.keys(objeto);
        var fila = $("<tr></tr>").attr("id","fila");
        $("#cuerpoTabla").append(fila);
        fila.dblclick(function(event){
            $("#form").show();
            event.preventDefault();
            node = event.currentTarget;
            fila = node.children;
            //console.log((fila[0]));
            //console.log((fila[0].firstChild));
            var indice = BuscaIndice((fila[0]).firstChild.textContent,array); 
            localStorage.setItem("indice",indice);
            $("#txtNombre").val(fila[1].innerHTML);
            $("#txtApellido").val(fila[2].innerHTML);
            if(fila[3].innerHTML == "Female"){
                $("#Femenino").prop( "checked", true );
            }
            else{
                $("#Masculino").prop("checked" , true);
            }
        });
        for(j = 0; j < 5; j++){
            
            if(j == 3){
                var localidad = Object.keys(objeto);
                //console.log(objeto.localidad.nombre)
                var celda = $("<td></td>").text(objeto.localidad.nombre);
                fila.append(celda);
            }
            else{
                var celda = $("<td></td>").text(objeto[columnas[j]]);
                fila.append(celda);
            }
        }
    }
}

function Guardar(){
    $("#spinner").hide();
    var indexAlumno = localStorage.getItem("indice");
    if($("#txtNombre").val() == "" || ($("#txtNombre").val()).length < 3){
        $("#txtNombre").addClass("Error");
    }
    else if($("#txtApellido").val() == "" || ($("#txtApellido").val()).length < 3){
        $("#txtApellido").addClass("Error");
    }
    else{
        personas[indexAlumno].id = personas[indexAlumno].id;
        personas[indexAlumno].nombre = $("#txtNombre").val();
        personas[indexAlumno].apellido = $("#txtApellido").val();

        if($("#Femenino").is(":checked") == true){
            personas[indexAlumno].sexo = "Female";
        }
        else{
            personas[indexAlumno].sexo = "Male";
        }
        personas[indexAlumno].localidad = { "id" : 17,"nombre":"Barracas"};
        
        $("#spinner").show(); console.log(personas[indexAlumno].localidad);
        $.post("http://localhost:3000/editar",{
            "id":personas[indexAlumno].id,
            "nombre":personas[indexAlumno].nombre,
            "apellido": personas[indexAlumno].apellido,
            "sexo":personas[indexAlumno].sexo,
            "localidad":personas[indexAlumno].localidad
        },function (data,status) {
            $("#spinner").hide();  
            if(data.type == "error"){
                 alert('ERROR');
            }
            else{
                alert("Se modificó correctamente.");
                location.reload();
                Cargar();
            }                            
        });
        $("#form").hide();
    }
}

function BuscaIndice(id,array){
    console.log(id,array.length);
    var retorno = -1;
    for(i=0;i<array.length;i++){
        console.log(id,array[i].id)
        if(id == ""+array[i].id){
            console.log("index",i);
            return i;
        }
    }

}

function cerrar(){
    $("#form").hide();
}