namespace Vehiculo{
    export class camioneta extends vehiculo{
        cuatroXcuatro:string;

        constructor(id:number,modelo:string,marca:string,precio:number,cuatroXcuatro:string){
            super(id,modelo,marca,precio);
            if(cuatroXcuatro != undefined){
                this.cuatroXcuatro = cuatroXcuatro;
            }
        }

        camionetaToJson():string{
            return JSON.stringify(this);
        }
    }
}