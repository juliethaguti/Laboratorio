var Vehiculo;
(function (Vehiculo) {
    var vehiculo = (function () {
        function vehiculo(id, modelo, marca, precio) {
            this.id = id;
            if (modelo != undefined) {
                this.modelo = modelo;
            }
            if (marca != undefined) {
                this.marca = marca;
            }
            if (precio != undefined) {
                this.precio = precio;
            }
        }
        vehiculo.prototype.vehiculoToJson = function () {
            return JSON.stringify(this);
        };
        return vehiculo;
    })();
    Vehiculo.vehiculo = vehiculo;
})(Vehiculo || (Vehiculo = {}));
