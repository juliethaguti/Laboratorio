var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var Vehiculo;
(function (Vehiculo) {
    var auto = (function (_super) {
        __extends(auto, _super);
        function auto(id, modelo, marca, precio, cantidadPuertas) {
            _super.call(this, id, modelo, marca, precio);
            if (cantidadPuertas != undefined) {
                this.cantidadPuertas = cantidadPuertas;
            }
        }
        auto.prototype.autoToJson = function () {
            return JSON.stringify(this);
        };
        return auto;
    })(Vehiculo.vehiculo);
    Vehiculo.auto = auto;
})(Vehiculo || (Vehiculo = {}));
