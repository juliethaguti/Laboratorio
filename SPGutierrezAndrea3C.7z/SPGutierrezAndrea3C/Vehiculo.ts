namespace Vehiculo{
    export class vehiculo{
        modelo:string;
        marca:string;
        id:number;
        precio:number;

        constructor(id:number,modelo:string,marca:string,precio:number){
            this.id = id;
            if(modelo != undefined){
                this.modelo = modelo;
            }

            if(marca != undefined){
                this.marca = marca;
            }

            if(precio != undefined){
                this.precio = precio;
            }
        }

        vehiculoToJson():string{
            return JSON.stringify(this);
        }
    }
}