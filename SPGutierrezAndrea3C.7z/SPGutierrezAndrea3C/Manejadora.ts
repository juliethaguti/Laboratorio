namespace Vehiculo{ 
    $(document).ready(function(){
        $('#btnAgregar').click(manejadora.agregarVehiculo);
        $('#Mostrar').click(manejadora.mostrarVehiculos);
        $('#Promedio').click(manejadora.promedioPrecio);
    });
    export class manejadora{

        static vehiculos:Array<Vehiculo.vehiculo> = new Array<Vehiculo.vehiculo>();

        public static agregarVehiculo():void{
            let marca:string = String($('#Marca').val());  
            let modelo:string = String($('#Modelo').val());
            let precio:number = Number($('#Precio').val());
            let Camioneta:string = String($('#Camioneta').val());
            let cantidadPuertas:number = Number($('#CantidadPuertas').val());
            let id = manejadora.CalcularId();
            let objeto:Vehiculo.vehiculo
            if( Camioneta == 'True' ){
                objeto = new camioneta(id,marca, modelo, precio, Camioneta);
            }
            else{
                objeto= new auto(id,marca, modelo, precio, cantidadPuertas);
            }
            
            if(manejadora.vehiculos == null){
                manejadora.vehiculos = [];
            }
            else{
                manejadora.vehiculos = JSON.parse(localStorage.getItem('listaVehiculos'));
            }
            
            manejadora.vehiculos.push(objeto);
            
            let lista = JSON.stringify(manejadora.vehiculos);
            console.log(lista);
            localStorage.setItem('listaVehiculos',lista);

            //manejadora.limpiarFormulario();
            manejadora.mostrarVehiculos();
        }

        static limpiarFormulario():void{
            $('#Nombre').val('');
            $('#Apellido').val('');
            $('#Legajo').val('');
            $('#Edad').val('');
            
        }
        static mostrarVehiculos():void{
            manejadora.vehiculos = JSON.parse(localStorage.getItem('listaVehiculos'));
            let tabla = "";
            $("#cuerpoTabla").html(tabla);

            manejadora.vehiculos.map(function(vehiculo){

                tabla = "<tr><td>";
                tabla += vehiculo.marca;
                tabla += "</td><td>";
                tabla += vehiculo.modelo;
                tabla += "</td><td>";
                tabla += vehiculo.precio;
                //tabla += "</td><td>";
                tabla += "</td><td><a onclick='Vehiculo.manejadora.eliminar(";
                tabla += vehiculo.id;
                tabla += ")'><span class='fa fa-trash-o'></span></a><a onclick='Persona.manejadora.modificar(";
                tabla += vehiculo.id;
                tabla +=")'><span class='fa fa-pencil-square-o'></span></a></td></tr>";
                $('#cuerpoTabla').append(tabla);
        });

    }

        static eliminar(i:number):void{
            manejadora.vehiculos = JSON.parse(localStorage.getItem('listaVehiculos'));
            
            for(let j= 0; j<manejadora.vehiculos.length;j++){
                if(i == manejadora.vehiculos[j].id){
                    manejadora.vehiculos.splice(j,1);
                    localStorage.setItem('listaVehiculos',JSON.stringify(manejadora.vehiculos));
                }
            }
            manejadora.mostrarVehiculos();
            
        }
        static filtrarPorMarca():void{
            manejadora.vehiculos = JSON.parse(localStorage.getItem('listaVehiculos'));
        }
        static promedioPrecio():void{
            manejadora.vehiculos = JSON.parse(localStorage.getItem('listaVehiculos'));
            
            function precios(total, vehiculo) {
                return total+vehiculo.precio;
              }

            let total =  manejadora.vehiculos.reduce(precios,0);
            let promedio = total/manejadora.vehiculos.length;
            alert('El promedio de precios es: '+promedio);
        }

        static CalcularId():number{
            manejadora.vehiculos = JSON.parse(localStorage.getItem('listaVehiculos'));
            /* function ids(total, vehiculo) {
                if(vehiculo.id>total){
                    return vehiculo.id
                }
                 
              }
              let id =  manejadora.vehiculos.reduce(ids);

              console.log(id);
              return 0; */
              if(manejadora.vehiculos == null){
                return 0;
              }
              else{
                  return manejadora.vehiculos.length;
              }
              
    }
}  

}


