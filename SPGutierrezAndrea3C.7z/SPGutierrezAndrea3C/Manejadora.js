var Vehiculo;
(function (Vehiculo) {
    $(document).ready(function () {
        $('#btnAgregar').click(manejadora.agregarVehiculo);
        $('#Mostrar').click(manejadora.mostrarVehiculos);
        $('#Promedio').click(manejadora.promedioPrecio);
    });
    var manejadora = (function () {
        function manejadora() {
        }
        manejadora.agregarVehiculo = function () {
            var marca = String($('#Marca').val());
            var modelo = String($('#Modelo').val());
            var precio = Number($('#Precio').val());
            var Camioneta = String($('#Camioneta').val());
            var cantidadPuertas = Number($('#CantidadPuertas').val());
            var id = manejadora.CalcularId();
            var objeto;
            if (Camioneta == 'True') {
                objeto = new Vehiculo.camioneta(id, marca, modelo, precio, Camioneta);
            }
            else {
                objeto = new Vehiculo.auto(id, marca, modelo, precio, cantidadPuertas);
            }
            if (manejadora.vehiculos == null) {
                manejadora.vehiculos = [];
            }
            else {
                manejadora.vehiculos = JSON.parse(localStorage.getItem('listaVehiculos'));
            }
            manejadora.vehiculos.push(objeto);
            var lista = JSON.stringify(manejadora.vehiculos);
            console.log(lista);
            localStorage.setItem('listaVehiculos', lista);
            //manejadora.limpiarFormulario();
            manejadora.mostrarVehiculos();
        };
        manejadora.limpiarFormulario = function () {
            $('#Nombre').val('');
            $('#Apellido').val('');
            $('#Legajo').val('');
            $('#Edad').val('');
        };
        manejadora.mostrarVehiculos = function () {
            manejadora.vehiculos = JSON.parse(localStorage.getItem('listaVehiculos'));
            var tabla = "";
            $("#cuerpoTabla").html(tabla);
            manejadora.vehiculos.map(function (vehiculo) {
                tabla = "<tr><td>";
                tabla += vehiculo.marca;
                tabla += "</td><td>";
                tabla += vehiculo.modelo;
                tabla += "</td><td>";
                tabla += vehiculo.precio;
                //tabla += "</td><td>";
                tabla += "</td><td><a onclick='Vehiculo.manejadora.eliminar(";
                tabla += vehiculo.id;
                tabla += ")'><span class='fa fa-trash-o'></span></a><a onclick='Persona.manejadora.modificar(";
                tabla += vehiculo.id;
                tabla += ")'><span class='fa fa-pencil-square-o'></span></a></td></tr>";
                $('#cuerpoTabla').append(tabla);
            });
        };
        manejadora.eliminar = function (i) {
            manejadora.vehiculos = JSON.parse(localStorage.getItem('listaVehiculos'));
            for (var j = 0; j < manejadora.vehiculos.length; j++) {
                if (i == manejadora.vehiculos[j].id) {
                    manejadora.vehiculos.splice(j, 1);
                    localStorage.setItem('listaVehiculos', JSON.stringify(manejadora.vehiculos));
                }
            }
            manejadora.mostrarVehiculos();
        };
        manejadora.filtrarPorMarca = function () {
            manejadora.vehiculos = JSON.parse(localStorage.getItem('listaVehiculos'));
        };
        manejadora.promedioPrecio = function () {
            manejadora.vehiculos = JSON.parse(localStorage.getItem('listaVehiculos'));
            function precios(total, vehiculo) {
                return total + vehiculo.precio;
            }
            var total = manejadora.vehiculos.reduce(precios, 0);
            var promedio = total / manejadora.vehiculos.length;
            alert('El promedio de precios es: ' + promedio);
        };
        manejadora.CalcularId = function () {
            manejadora.vehiculos = JSON.parse(localStorage.getItem('listaVehiculos'));
            /* function ids(total, vehiculo) {
                if(vehiculo.id>total){
                    return vehiculo.id
                }
                 
              }
              let id =  manejadora.vehiculos.reduce(ids);

              console.log(id);
              return 0; */
            if (manejadora.vehiculos == null) {
                return 0;
            }
            else {
                return manejadora.vehiculos.length;
            }
        };
        manejadora.vehiculos = new Array();
        return manejadora;
    })();
    Vehiculo.manejadora = manejadora;
})(Vehiculo || (Vehiculo = {}));
