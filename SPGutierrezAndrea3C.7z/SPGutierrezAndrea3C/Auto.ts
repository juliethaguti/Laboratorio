namespace Vehiculo{
    export class auto extends vehiculo{
        cantidadPuertas:number;

        constructor(id:number,modelo:string,marca:string,precio:number,cantidadPuertas:number){
            super(id,modelo,marca,precio);
            if(cantidadPuertas != undefined){
                this.cantidadPuertas = cantidadPuertas;
            }
        }

        autoToJson():string{
            return JSON.stringify(this);
        }
    }
}