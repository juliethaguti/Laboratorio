var xhr = new XMLHttpRequest();

window.addEventListener("load", function(){
    /*xhr.open("GET","http://localhost:3000/personas",true);
    xhr.onreadystatechange = getPersonas;
    xhr.send();*/
    abrir(false);
});

/*function $(id){
    return document.getElementById(id);
}*/

function agregar(){ 
    abrir(true);
    limpiar();
}

function abrir(mostrar){
    var contAgregar = document.getElementById("contenedor");
    var btnAgregar = document.getElementById("btnAgregar");
    btnAgregar.hidden = mostrar;

    contAgregar.hidden = !mostrar;
}

function guardar(){
    //var nombre = $("Nombre").value;
    //var apellido = $("Apellido").value;
    var nombre = document.getElementById("Nombre").value;
    var apellido  = document.getElementById("Apellido").value;

    if(apellido == "" || nombre == "")
    {
        document.getElementById("Nombre").className="conError";
        document.getElementById("Apellido").className="conError";
        alert("Debe ingresar un nombre y un apellido");
    }
    else{
        var respuesta = confirm("Esta seguro que desea agregar a un persona?");
        if(respuesta == true)
        {
            document.getElementById("Nombre").className="sinError";
            document.getElementById("Apellido").className="sinError";
            var tCuerpo = document.getElementById("cuerpoTabla");

            tCuerpo.innerHTML = tCuerpo.innerHTML +
            "<tr><td>"+nombre+"</td><td>"+apellido+"</td><td><a href='' onclick='Borrar(event)'>borrar</a></td><td><a href=''onclick='Editar(event)'>Editar</a></td></tr>";
            cerrar();   
        }
    }
}

function cerrar(){
    abrir(false);
}

function limpiar(){
    document.getElementById("Nombre").value="";
    document.getElementById("Apellido").value="";
}

function getPersonas(){
    if(xhr.readyState === 4){
       
        if(xhr.status === 200){
            var respuesta = xhr.responseText;
            if(respuesta != ""){
                var arrayPersonas=JSON.parse(respuesta);
                agregarAGrilla(arrayPersonas);
            }
        }
    }
       
    
}

function agregarAGrilla(array){
    
    var tabla = document.getElementById("table");
    var count = array.length;
    for(var i = 0; i<count;i++){
        tabla += "<tr><td>";
        tabla += array[i].nombre;
        tabla += "</td><td>";
        tabla += array[i].apellido;
        tabla += "</td><td>";
        tabla += array[i].fecha;
        tabla += "</td><td>";
        tabla += array[i].telefono;
        tabla += "</td></tr>"
    }
    document.getElementById("cuerpoTabla").innerHTML = tabla;
}

function Borrar(e){
    //propiedad target: cual fue el elemento que ejecuto el evento.
    e.preventDefault(); //Para que me deje acceder a los hijos, sacar el valor por defecto.
    console.log(e.target);
    console.log(e.target.parentNode);
    console.log(e.target.parentNode.parentNode);

    e.target.parentNode.parentNode.innerHTML="";
}

function Editar(e){
    e.preventDefault();
    var nombre = e.target.parentNode.parentNode.children[0].innerHTML;
    var apellido = e.target.parentNode.parentNode.children[1].innerHTML;
    document.getElementById('Nombre').value = nombre;
    document.getElementById('Apellido').value = apellido;
    abrir(true);
    guardar();
}