var xhr = new XMLHttpRequest();
var httpReq = new XMLHttpRequest();

window.addEventListener("load",function(){
    document.getElementById("contenedor").hidden = true;
    document.getElementById("titulo").hidden = true;
    Cargar();
});

function Cargar(){
    xhr.open("GET","http://localhost:3000/notas",true);
    xhr.onreadystatechange = callback;
    xhr.send(); 
}
function callback(){
    document.getElementById("spinner").hidden=false;
    if(xhr.readyState === 4 && xhr.status === 200){
        document.getElementById("spinner").hidden=true;
        var respuesta = JSON.parse(xhr.responseText);
        var tipo = localStorage.getItem("type");
        //console.log(respuesta);
        localStorage.setItem("notas",xhr.responseText);
        agregarAGrilla(respuesta, tipo);
    }
    else{
    console.log("ERROR "+xhr.status);
    }
}

function agregarAGrilla(array, tipoUsuario){
    var cuerpoTabla = document.getElementById("cuerpoTabla");
    for(var i = 0; i<array.length;i++){
        var fila = document.createElement("tr");
        var objeto = array[i];
        var columnas = Object.keys(objeto);
        cuerpoTabla.appendChild(fila);
        for(j = 0; j < columnas.length; j++){
            
            var celda = document.createElement("td");
            var textoCelda = document.createTextNode(objeto[columnas[j]]);
            //console.log(columnas[j]);
            if(columnas[j] == "nota" && objeto[columnas[j]] < 4){
              fila.className = "desaprobado";  
            }
            
            fila.appendChild(celda);
            celda.appendChild(textoCelda);
            if(tipoUsuario === "Admin" && j == columnas.length-1){
                document.getElementById("titulo").hidden = false;
                var celdaEditar = document.createElement("td");
                var tagA = document.createElement("a");
                var text = document.createTextNode("Editar");
                tagA.href = "#";
                fila.appendChild(celdaEditar);
                celdaEditar.appendChild(tagA);
                tagA.appendChild(text);
                //document.getElementsByTagName("a").setAttribute("id", "tagA");
                tagA.onclick = editar;
            }
        }
    }
    /* var tabla = "";
    
    for(var i = 0; i<array.length;i++){
        if(array[i].nota <= 4){
            tabla += "<tr class = 'desaprobado'>";
        }
        else{
            tabla += "<tr>";
        }
        tabla += "<td>";
        tabla += array[i].id;
        tabla += "</td><td>";
        tabla += array[i].legajo;
        tabla += "</td><td>";
        tabla += array[i].nombre;
        tabla += "</td><td>";
        tabla += array[i].materia;
        tabla += "</td><td>";
        tabla += "</td>";
        tabla += array[i].nota;
        if(tipoUsuario === "Admin"){
            tabla += "<td><a> onclik='editar("+i+",event)'href='#'>Editar</a></td>";
        }
        tabla += "</tr>"
    }
    document.getElementById("cuerpoTabla").innerHTML = tabla; */
}

/* function callbackForm(){
    //document.getElementById("imgLoading").className="imagenVisible";
    if(xhr.readyState === 4 && xhr.status === 200){
        //document.getElementById("imgLoading").className="imagenInvisible";
        console.log(xhr.responseText);
        var respuesta = JSON.parse(xhr.responseText);
        
    }
    else{
    console.log("ERROR "+xhr.status);
    }
} */

function editar(i){
    document.getElementById("contenedor").hidden = false;
    i.preventDefault();
    fila = i.target.parentNode.parentNode.children;
    var indice = BuscaIndice(parseInt((fila[0]).innerHTML));
    //console.log(indice);
    sessionStorage.setItem("indice",indice);
    document.getElementById("txtLegajo").value = fila[1].innerHTML;
    document.getElementById("txtNombre").value = fila[2].innerHTML;
    document.getElementById("txtMateria").value = fila[3].innerHTML;
    document.getElementById("txtNota").value = fila[4].innerHTML;
    
}


function Guardar(){
    var indexAlumno = sessionStorage.getItem("indice");
    var notas = JSON.parse(localStorage.getItem("notas"));
    notas[indexAlumno].legajo = document.getElementById("txtLegajo").value;
    notas[indexAlumno].nombre = document.getElementById("txtNombre").value;
    notas[indexAlumno].materia = document.getElementById("txtMateria").value;
    notas[indexAlumno].nota = document.getElementById("txtNota").value;

    spinner.hidden = false;
    httpReq.open("POST","http://localhost:3000/editarNota");
    httpReq.onreadystatechange = callBackMod;
    httpReq.setRequestHeader("Content-Type","application/json");
    httpReq.send(JSON.stringify(notas[indexAlumno]));
    document.getElementById("contenedor").hidden = true;
}

function BuscaIndice(id){
    var notas = JSON.parse(localStorage.getItem("notas"));
    var retorno = -1;
    for(i=0;i<notas.length;i++){
        if(id == notas[i].id){
            retorno = i;
            break;
        }
    }
    return retorno;
}


var callBackMod = function () {
    if (httpReq.readyState === 4) {       
        if (httpReq.status == 200) { 
            console.log(httpReq.responseText);
            var respuesta = JSON.parse(httpReq.responseText);            
            
            if(respuesta.type == "error"){
                alert(respuesta.message);
            }
            else{
                alert("Se modificó correctamente.");
                Cargar();
            }                            
        }
        else {
            console.log("Ocurrió un error en el servidor. Código: " + httpReq.status);
        }
    }
}

window.onload = Cargar;

function cerrar(){
    document.getElementById("contenedor").hidden = true;
}
/*
function pedirNotasGet(){
    ajax("GET","http://localhost:3000/notas","",true,callBack);
}

function ajax(metodo, url, parametros, tipo, callback) {
    httpReq.onreadystatechange = callback;
    if (metodo === "GET") {
        httpReq.open("GET", url, tipo); //abre la conexión con el servidor
        httpReq.send();
    }
    else {
        httpReq.open("POST", url, tipo); //abre la conexión con el servidor
        //httpReq.setRequestHeader("Content-Type","application/x-www-form-urlencoded"); //string
        httpReq.setRequestHeader("Content-Type", "application/json"); //string
        httpReq.send(parametros);
    }
}

window.onload = pedirNotasGet */
