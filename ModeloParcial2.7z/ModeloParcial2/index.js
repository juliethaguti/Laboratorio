var xhr = new XMLHttpRequest();

window.addEventListener("load",function(){
    document.getElementById("titulo").hidden = true;
    xhr.open("GET","http://localhost:3000/notas",true);
   xhr.onreadystatechange = callback;
   xhr.send(); 
});

function callback(){
    document.getElementById("spinner").hidden=false;
    if(xhr.readyState === 4 && xhr.status === 200){
        document.getElementById("spinner").hidden=true;
        var respuesta = JSON.parse(xhr.responseText);
        var tipo = localStorage.getItem("type");
        //console.log(respuesta);
        //localStorage.setItem("notas",xhr.responseText);
        agregarAGrilla(respuesta, tipo);
    }
    else{
    console.log("ERROR "+xhr.status);
    }
}

function agregarAGrilla(array, tipoUsuario){
    var cuerpoTabla = document.getElementById("cuerpoTabla");
    for(var i = 0; i<array.length;i++){
        var fila = document.createElement("tr");
        var objeto = array[i];
        var columnas = Object.keys(objeto);
        cuerpoTabla.appendChild(fila);
        for(j = 0; j < columnas.length; j++){
            
            var celda = document.createElement("td");
            var textoCelda = document.createTextNode(objeto[columnas[j]]);
            //console.log(columnas[j]);
            if(columnas[j] == "nota" && objeto[columnas[j]] < 4){
              fila.className = "desaprobado";  
            }
            
            fila.appendChild(celda);
            celda.appendChild(textoCelda);
            if(tipoUsuario === "Admin" && j == columnas.length-1){
                document.getElementById("titulo").hidden = false;
                var celdaEditar = document.createElement("td");
                var tagA = document.createElement("a");
                var text = document.createTextNode("Editar");
                tagA.href = "#";
                fila.appendChild(celdaEditar);
                celdaEditar.appendChild(tagA);
                tagA.appendChild(text);
                tagA.onclick = editar;
            }
        }
    }
    /* var tabla = "";
    
    for(var i = 0; i<array.length;i++){
        if(array[i].nota <= 4){
            tabla += "<tr class = 'desaprobado'>";
        }
        else{
            tabla += "<tr>";
        }
        tabla += "<td>";
        tabla += array[i].id;
        tabla += "</td><td>";
        tabla += array[i].legajo;
        tabla += "</td><td>";
        tabla += array[i].nombre;
        tabla += "</td><td>";
        tabla += array[i].materia;
        tabla += "</td><td>";
        tabla += "</td>";
        tabla += array[i].nota;
        if(tipoUsuario === "Admin"){
            tabla += "<td><a> onclik='editar("+i+",event)'href='#'>Editar</a></td>";
        }
        tabla += "</tr>"
    }
    document.getElementById("cuerpoTabla").innerHTML = tabla; */
}

function callbackForm(){
    document.getElementById("imgLoading").className="imagenVisible";
    if(xhr.readyState === 4 && xhr.status === 200){
        document.getElementById("imgLoading").className="imagenInvisible";
        console.log(xhr.responseText);
        var respuesta = JSON.parse(xhr.responseText);
        
    }
    else{
    console.log("ERROR "+xhr.status);
    }
}

function editar(i){
    var notas = JSON.parse(localStorage.getItem("notas"))[i];
    document.getElementById("txtLegajo").value = notas.legajo;
    document.getElementById("txtNombre").value = notas.nombre;
    document.getElementById("txtMateria").value = notas.materia;
    document.getElementById("txtNota").value = notas.nota;
    document.getElementById("indexAlumno").value = i;
    document.getElementById("divNuevoPost").className = "divNuevoPost divNuevoPostVisible";
}

/*

var callBackMod = function () {
    document.getElementById("imgLoading").className = "imgLoadingVisible";
    if (httpReq.readyState === 4) { //Acá hay respuesta del servidor!!      
        if (httpReq.status == 200) { //Codigo de que todo está bien.
            console.log(httpReq.responseText);
            var respuesta = JSON.parse(httpReq.responseText);            
            document.getElementById("imgLoading").className = "imgLoadingInvisible";
            document.getElementById("divNuevoPost").className = "divNuevoPost divNuevoPostInvisible";
            if(respuesta.type == "error"){
                alert(respuesta.message);
            }
            else{
                alert("Se modificó correctamente.");
                pedirNotasGet();
            }                            
        }
        else {
            console.log("Ocurrió un error en el servidor. Código: " + httpReq.status);
        }
    }
}

function cargarLista(){
    var tipoUsuario = JSON.parse(localStorage.getItem("tipo")).type;
    var notas = JSON.parse(localStorage.getItem("notas"));
    var count = Object.keys(notas).length;
    var tablaHTML = "<caption></caption>\
    <thead>\
        <tr>\
            <th>Legajo</th>\
            <th>Nombre</th>\
            <th>Materia</th>\
            <th>Nota</th>";
            if(tipoUsuario === "Admin"){
                tablaHTML += "<th>Acción</th>";
            }            
        tablaHTML += "</tr>\
    </thead>\
    <tbody>";    
    for(i = 0; i < count; i++){
        if(notas[i].nota >= 4){
            tablaHTML += "<tr>"
        }
        else{
            tablaHTML += "<tr class='desaprobado'>"
        }
        tablaHTML += "<td>"+notas[i].legajo+"</td>\
        <td>"+notas[i].nombre+"</td>\
        <td>"+notas[i].materia+"</td>\
        <td>"+notas[i].nota+"</td>";
        if(tipoUsuario === "Admin"){
            tablaHTML += "<td><a onclick='editar("+i+",event)' href='#'>Editar</a></td></tr>"; 
        }            
        else{
            tablaHTML += "</tr>"
        }                      
    } 
    tablaHTML += "</tbody>";
    document.getElementById("tabla").innerHTML = tablaHTML;
}

function pedirNotasGet(){
    ajax("GET","http://localhost:3000/notas","",true,callBack);
}

function ajax(metodo, url, parametros, tipo, callback) {
    httpReq.onreadystatechange = callback;
    if (metodo === "GET") {
        httpReq.open("GET", url, tipo); //abre la conexión con el servidor
        httpReq.send();
    }
    else {
        httpReq.open("POST", url, tipo); //abre la conexión con el servidor
        //httpReq.setRequestHeader("Content-Type","application/x-www-form-urlencoded"); //string
        httpReq.setRequestHeader("Content-Type", "application/json"); //string
        httpReq.send(parametros);
    }
}

function Cerrar(){
    document.getElementById("divNuevoPost").className = "divNuevoPost divNuevoPostInvisible";
}

function Guardar(){
    var indexAlumno = document.getElementById("indexAlumno").value;
    var notas = JSON.parse(localStorage.getItem("notas"));
    notas[indexAlumno].legajo = document.getElementById("txtLegajo").value;
    notas[indexAlumno].nombre = document.getElementById("txtNombre").value;
    notas[indexAlumno].materia = document.getElementById("txtMateria").value;
    notas[indexAlumno].nota = parseInt(document.getElementById("txtNota").value);

    ajax("POST","http://localhost:3000/editarNota",JSON.stringify(notas[indexAlumno]),true,callBackMod);
}

window.onload = pedirNotasGet */
