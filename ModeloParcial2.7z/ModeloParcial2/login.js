var xhr = new XMLHttpRequest();

window.addEventListener("load", function(){
    var spinner = document.getElementById("spinner");
    spinner.hidden = true;
    var btnEntrar = this.document.getElementById("entrar");
    btnEntrar.addEventListener("click",enviar);
    
});

function enviarPost(){
    var spinner = document.getElementById("spinner");
    if(xhr.readyState === 4){
        if(xhr.status === 200){
            var respuesta = JSON.parse(xhr.responseText);
            console.log(respuesta);
            if(respuesta.type == "User" || respuesta.type == "Admin")
            {
                var email = document.getElementById("txtEmail").value;
                localStorage.setItem("type",respuesta.type);
                localStorage.setItem("email",email);
                spinner.hidden = true;
                window.location.replace("./index.html");
            }
            else if(respuesta.type == "error"){
                spinner.hidden = true;
                var lblMensaje = document.getElementById("advertencia");
                lblMensaje.hidden = false;
                document.getElementById("txtEmail").className = "error";
                document.getElementById("txtPassword").className = "error";                     
            }
            else{
                console.log(respuesta);
            }
        }
    }
}

function enviar(){
    var email = document.getElementById("txtEmail").value;
    var pass = document.getElementById("txtPassword").value;
    var spinner = document.getElementById("spinner");

    var datosLogin = {email:email,password:pass}
    
    spinner.hidden = false;
    xhr.open("POST","http://localhost:3000/login");
    xhr.onreadystatechange = enviarPost;
    xhr.setRequestHeader("Content-Type","application/json");
    xhr.send(JSON.stringify(datosLogin));
}