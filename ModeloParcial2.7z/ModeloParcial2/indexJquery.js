$(document).ready(function(){
    $("#contenedor").hide();
    $("#titulo").hide();
    $.get("http://localhost:3000/notas",function(data, status){
        $("#spinner").hide();
        agregarAGrilla(data, data.type);
    });
});

function agregarAGrilla(array, tipoUsuario){
    //var cuerpoTabla = document.getElementById("cuerpoTabla");
    for(var i = 0; i<array.length;i++){
        var fila =  
        var objeto = array[i];
        var columnas = Object.keys(objeto);
        $("cuerpoTabla").append("<tr></tr>");
        for(j = 0; j < columnas.length; j++){
            
            var celda = document.createElement("td");
            var textoCelda = document.createTextNode(objeto[columnas[j]]);
            //console.log(columnas[j]);
            if(columnas[j] == "nota" && objeto[columnas[j]] < 4){
                $("#txtEmail").addClass("Error");
                fila.className = "desaprobado";  
            }
            
            fila.appendChild(celda);
            celda.appendChild(textoCelda);
            if(tipoUsuario === "Admin" && j == columnas.length-1){
                document.getElementById("titulo").hidden = false;
                var celdaEditar = document.createElement("td");
                var tagA = document.createElement("a");
                var text = document.createTextNode("Editar");
                tagA.href = "#";
                fila.appendChild(celdaEditar);
                celdaEditar.appendChild(tagA);
                tagA.appendChild(text);
                //document.getElementsByTagName("a").setAttribute("id", "tagA");
                tagA.onclick = editar;
            }
        }
    }
}