var personas;
$(document).ready(function(){
    $("#spinner").hide();
    $("#entrar").click(function(){
        
        var datosLogin = {email:$("#txtEmail").val(),password:$("#txtPassword").val()}
        
        $("#spinner").show();
        $.post("http://localhost:3000/login",datosLogin,function (data,status) {
            
            if(data.type == "User" || data.type == "Admin")
            {
                var email = document.getElementById("txtEmail").value;
                localStorage.setItem("type",data.type);
                //localStorage.setItem("email",email);
                $("#spinner").hide();
                window.location.replace("./index.html");
            }
            else if(data.type == "error"){
                $("#spinner").hide();
                $("#advertencia").show();
                $("#txtEmail").addClass("Error");
                $("#txtPassword").addClass("Error");
            }                            
        });    
    });
});

